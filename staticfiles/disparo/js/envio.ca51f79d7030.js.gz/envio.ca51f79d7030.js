function confirmar() {
    showLoadingIndicator()
    document.getElementById('form_confirmar').submit();
}

function cancelar() {
    window.location.href = enviar_disparo_url;
}


     

